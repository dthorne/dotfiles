#!/bin/bash

set -xe
VERSION=2.0 ./runtest.sh
VERSION=2.1 ./runtest.sh
VERSION=2.2 ./runtest.sh
VERSION=2.3 ./runtest.sh
VERSION=2.4 ./runtest.sh
VERSION=2.5 ./runtest.sh
VERSION=2.6 ./runtest.sh
VERSION=2.7 ./runtest.sh
VERSION=2.8 ./runtest.sh
VERSION=2.9 ./runtest.sh
VERSION=3.0 ./runtest.sh
VERSION=3.1 ./runtest.sh
VERSION=3.2 ./runtest.sh
