import {someVar} from './some-module';
document.getElementById('myApp');
