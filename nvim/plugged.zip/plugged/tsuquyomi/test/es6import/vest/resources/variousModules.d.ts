declare namespace NS {
    namespace nestedNS {
    }
}

declare namespace NS.nestedNS {
}

declare module InternalModule {
}

declare module InternalModule.SubModule {
}

declare module 'external-module' {
}

declare module "external-module/alt" {
}
