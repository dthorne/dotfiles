import { someVar } from './some-module';
class Hoge {
    private hoge: string;
}
