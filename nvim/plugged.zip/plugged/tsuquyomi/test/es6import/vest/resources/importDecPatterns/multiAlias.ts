import {
    someVar,
    altVar
} from './some-module';
