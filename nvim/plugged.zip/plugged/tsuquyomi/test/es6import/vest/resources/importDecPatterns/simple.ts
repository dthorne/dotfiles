import { someVar } from './some-module';
