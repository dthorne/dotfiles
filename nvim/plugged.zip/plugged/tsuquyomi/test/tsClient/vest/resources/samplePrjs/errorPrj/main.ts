interface Hoge {
    id: any;
    // syntaxerror
    foo: {
}
