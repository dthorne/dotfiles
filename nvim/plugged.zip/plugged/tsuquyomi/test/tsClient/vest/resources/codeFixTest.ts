class Hoge {
    constructor() { }
}

class Foo extends Hoge {
    constructor() {
    }
}
