module ReferenceTest {
  export class SomeClass {
  }

  export class OtherClass extends SomeClass{
  }
}
