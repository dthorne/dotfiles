class App { }
var app = new App();

