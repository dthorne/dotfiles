/// <reference path="referencesTestA.ts" />

module ReferenceTest {
  export class AnotherClass extends SomeClass{
  }
}
