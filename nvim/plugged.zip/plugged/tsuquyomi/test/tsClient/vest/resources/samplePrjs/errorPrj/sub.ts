class Foo extends InvalidBaseClass {}
