module main {
    interface IBase {}

    class BaseClazz implements IBase {}
}
